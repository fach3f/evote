<div class="welcome">
   <h2>Selamat Datang di E - Voting</h2>
   <p style="font-size:18px;">Anda login sebagai <strong><?php echo $_SESSION['user']; ?></strong> dengan hak akses terbatas</p>
</div>
